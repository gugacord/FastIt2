package com.delivery.fastit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ItemDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
    }
}
