package com.delivery.fastit.Common;

import com.delivery.fastit.User;

public class Common {
    public static User currentUser;
}
